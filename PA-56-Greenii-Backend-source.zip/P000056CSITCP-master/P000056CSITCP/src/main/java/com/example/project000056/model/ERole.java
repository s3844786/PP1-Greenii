package com.example.project000056.model;

public enum ERole {
  ROLE_USER,
  ROLE_MODERATOR,
  ROLE_ADMIN,
  ROLE_DRIVER
}
