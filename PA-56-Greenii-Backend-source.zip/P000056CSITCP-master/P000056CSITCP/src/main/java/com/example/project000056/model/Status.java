package com.example.project000056.model;

public enum Status {
    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}
