package com.example.project000056;

//import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project000056ApplicationTests {

    @Test
    void contextLoads() {
    }

}
